﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace donacije
{
    public partial class Donacije : Form
    {
        public Donacije()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double ukupno = 0;
            double najvise = 0;
        }

        private void Donacije_Load(object sender, EventArgs e)
        {

        }
    }
}
