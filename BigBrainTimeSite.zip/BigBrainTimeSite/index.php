<?php include "./php/inc/header.php"; ?>
<div class="image"></div>
    <div id="container">

       <h1 id="naslov">Pomozimo zajedno</h1>
<div>
    <p id="tekst">
        Invalidnost je fizički ili mentalni nedostatak, koji ograničava osobu u jednoj ili više životnih aktivnosti. <br>
        U mnogim državama danas postoje zadruge, koje pomažu invalidnim osobama, da im se olakša život i da ih se što više uključi u društvo. <br>
        Neki su rođeni sa nedostacima, drugi su ih stekli u različitim trenucima života, za neke, stanje je samo privremeno, za druge pak trajno.
    </p>
</div>


    <img id="malaSlika" src="imgs/naslovna/malaSlika.jpg" alt="" srcset="">


    

    </div>
<?php include "./php/inc/footer.php"; ?>