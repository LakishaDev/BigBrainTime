<?php
include "./php/inc/init.php";
session_destroy();
redirect("index.php");
?>