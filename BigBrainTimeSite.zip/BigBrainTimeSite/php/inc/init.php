<?php
    session_start();

    include "./php/db/konekcija.php";
    include "./php/funkcije.php";
?>